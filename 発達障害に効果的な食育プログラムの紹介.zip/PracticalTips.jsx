import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Home, Clock, Users, CheckCircle } from 'lucide-react';
import familyMealImage from '../assets/family_meal_together.jpg';

const PracticalTips = () => {
  const [openTip, setOpenTip] = useState(0);

  const tips = [
    {
      icon: <Home className="w-6 h-6 text-green-600" />,
      title: "家庭での環境づくり",
      description: "食事に集中できる環境を整えることから始めましょう",
      details: [
        "食事中はテレビを消し、静かな環境を作る",
        "決まった席で食事をする習慣をつける",
        "食器や調理器具を子どもの手の届く場所に配置",
        "視覚的な手がかり（絵カードなど）を活用する"
      ]
    },
    {
      icon: <Clock className="w-6 h-6 text-blue-600" />,
      title: "段階的なアプローチ",
      description: "無理をせず、小さなステップから始めることが大切です",
      details: [
        "新しい食材は少量から始める",
        "見る→触る→匂いを嗅ぐ→舐める→食べるの順序で進める",
        "子どものペースに合わせて進行する",
        "成功体験を積み重ねて自信をつける"
      ]
    },
    {
      icon: <Users className="w-6 h-6 text-orange-600" />,
      title: "家族での取り組み",
      description: "家族全員で食育に取り組むことで効果が高まります",
      details: [
        "家族みんなで同じ食事を楽しむ",
        "子どもと一緒に買い物や調理をする",
        "食事の準備や片付けを手伝ってもらう",
        "食材の話や栄養について会話する"
      ]
    },
    {
      icon: <CheckCircle className="w-6 h-6 text-purple-600" />,
      title: "継続のコツ",
      description: "長期的な視点で継続することが成功の鍵です",
      details: [
        "小さな変化も認めて褒める",
        "記録をつけて成長を可視化する",
        "専門家や他の保護者と情報交換する",
        "完璧を求めず、できることから始める"
      ]
    }
  ];

  const quickTips = [
    "感覚過敏の子には手袋やエプロンを用意する",
    "好きな食材から新しい調理法を試す",
    "食事の時間を楽しい時間にする工夫をする",
    "子どもの「できた！」を大切にする",
    "無理強いはせず、見守る姿勢を大切にする"
  ];

  return (
    <section id="tips" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            家庭でできる実践方法
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            専門的なプログラムで学んだことを家庭でも実践できるよう、
            具体的な方法とコツをご紹介します。
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div>
            <img
              src={familyMealImage}
              alt="家族で楽しく食事をしている様子"
              className="w-full h-auto rounded-2xl shadow-lg"
            />
          </div>
          
          <div className="space-y-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              今日から始められる5つのポイント
            </h3>
            {quickTips.map((tip, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="w-6 h-6 bg-green-500 text-white rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 mt-1">
                  {index + 1}
                </div>
                <p className="text-gray-700 leading-relaxed">{tip}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            詳しい実践ガイド
          </h3>
          {tips.map((tip, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-md overflow-hidden"
            >
              <button
                onClick={() => setOpenTip(openTip === index ? -1 : index)}
                className="w-full px-6 py-4 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
              >
                <div className="flex items-center space-x-4">
                  <div className="flex items-center justify-center w-12 h-12 bg-gray-100 rounded-full">
                    {tip.icon}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">
                      {tip.title}
                    </h4>
                    <p className="text-gray-600 text-sm">
                      {tip.description}
                    </p>
                  </div>
                </div>
                {openTip === index ? (
                  <ChevronUp className="w-5 h-5 text-gray-400" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-gray-400" />
                )}
              </button>
              
              {openTip === index && (
                <div className="px-6 pb-6">
                  <div className="pl-16">
                    <ul className="space-y-3">
                      {tip.details.map((detail, detailIndex) => (
                        <li key={detailIndex} className="flex items-start space-x-3">
                          <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                          <span className="text-gray-700">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="mt-16 bg-blue-50 rounded-2xl p-8 border border-blue-200">
          <div className="text-center">
            <h3 className="text-xl font-bold text-blue-900 mb-4">
              困ったときは専門家にご相談ください
            </h3>
            <p className="text-blue-700 mb-6">
              一人で悩まず、管理栄養士や発達支援の専門家と一緒に最適な方法を見つけましょう
            </p>
            <a
              href="#contact"
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors duration-200 inline-block"
            >
              専門家に相談する
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PracticalTips;

