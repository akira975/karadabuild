import React from 'react';
import { ArrowDown } from 'lucide-react';
import heroImage from '../assets/hero_children_cooking.jpg';

const HeroSection = () => {
  return (
    <section className="relative bg-gradient-to-br from-green-50 to-orange-50 py-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
              毎日の食事で、
              <span className="text-green-600">笑顔</span>と
              <span className="text-orange-500">健康</span>を
              育てよう！
            </h1>
            <p className="text-xl md:text-2xl text-gray-700 mb-8 leading-relaxed">
              発達障害への効果的な食育プログラム
            </p>
            <p className="text-lg text-gray-600 mb-10 leading-relaxed">
              子どもたちの個性を大切にしながら、食を通じて成長をサポートします。
              専門的な知識と実践的なアプローチで、家族みんなが笑顔になれる食育を提供します。
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a
                href="#programs"
                className="bg-green-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-700 transition-colors duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
              >
                プログラムを見る
              </a>
              <a
                href="#contact"
                className="bg-white text-green-600 border-2 border-green-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-green-50 transition-colors duration-200"
              >
                お問い合わせ
              </a>
            </div>
          </div>
          
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img
                src={heroImage}
                alt="子どもたちが楽しく料理をしている様子"
                className="w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
            </div>
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-24 h-24 bg-orange-200 rounded-full opacity-60"></div>
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-green-200 rounded-full opacity-40"></div>
          </div>
        </div>
      </div>
      
      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown className="text-gray-400" size={32} />
      </div>
    </section>
  );
};

export default HeroSection;

