import React from 'react';
import { Quote, Star } from 'lucide-react';

const SuccessStories = () => {
  const stories = [
    {
      name: "田中さん（10歳男児の母）",
      childAge: "10歳",
      condition: "ASD・ADHD",
      story: "感覚過敏で白米を食べるのも苦手だった息子が、自分で握ったおにぎりを完食できました。みんなと一緒だったから食べられたのだと思います。途中で泣いてしまったけど、温かく見守ってくれたスタッフの皆さんに感謝しています。",
      improvement: "偏食の改善、食事への興味向上",
      rating: 5
    },
    {
      name: "佐藤さん（8歳女児の母）",
      childAge: "8歳",
      condition: "感覚過敏",
      story: "野菜を触ることすら嫌がっていた娘が、今では簡単な野菜の皮むきができるようになりました。段階的なアプローチで、無理をせずに進められたのが良かったです。家でも料理のお手伝いをしてくれるようになりました。",
      improvement: "調理スキルの習得、自信の向上",
      rating: 5
    },
    {
      name: "山田さん（12歳男児の父）",
      childAge: "12歳",
      condition: "不登校・発達障害",
      story: "学校に行けない息子にとって、食育プログラムは貴重な社会参加の機会でした。他の子どもたちと協力して料理を作る中で、コミュニケーション能力が向上し、自己肯定感も高まりました。",
      improvement: "社会性の発達、コミュニケーション能力向上",
      rating: 5
    }
  ];

  const statistics = [
    { number: "95%", label: "参加者の食事への興味向上" },
    { number: "87%", label: "偏食の改善が見られた" },
    { number: "92%", label: "保護者の満足度" },
    { number: "124回", label: "累計実施回数" }
  ];

  return (
    <section id="success" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            成功事例と参加者の声
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            実際にプログラムに参加された子どもたちとご家族の体験談をご紹介します。
            一人ひとりの成長の軌跡が、食育の可能性を物語っています。
          </p>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          {statistics.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl md:text-4xl font-bold text-green-600 mb-2">
                {stat.number}
              </div>
              <div className="text-gray-600 text-sm md:text-base">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Success Stories */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {stories.map((story, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-green-50 to-blue-50 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="flex items-center justify-between mb-6">
                <Quote className="text-green-600 w-8 h-8" />
                <div className="flex space-x-1">
                  {[...Array(story.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {story.name}
                </h3>
                <div className="text-sm text-gray-600 mb-4">
                  <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full mr-2">
                    {story.childAge}
                  </span>
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full">
                    {story.condition}
                  </span>
                </div>
              </div>
              
              <blockquote className="text-gray-700 leading-relaxed mb-6 italic">
                "{story.story}"
              </blockquote>
              
              <div className="bg-white rounded-lg p-4 border-l-4 border-green-500">
                <h4 className="font-semibold text-green-800 mb-2">改善された点</h4>
                <p className="text-green-700 text-sm">{story.improvement}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">
            あなたのお子さまも変化を実感できます
          </h3>
          <p className="text-lg mb-6 opacity-90">
            一人ひとりの特性に合わせたサポートで、食を通じた成長をお手伝いします
          </p>
          <a
            href="#contact"
            className="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200 inline-block"
          >
            無料相談を申し込む
          </a>
        </div>
      </div>
    </section>
  );
};

export default SuccessStories;

