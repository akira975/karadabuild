import React from 'react';
import { ChefHat, BookOpen, Palette } from 'lucide-react';
import cookingImage from '../assets/children_helping_kitchen.jpg';

const ProgramSection = () => {
  const programs = [
    {
      icon: <ChefHat className="w-12 h-12 text-orange-500" />,
      title: "調理活動",
      description: "安全な調理器具の使い方を学び、食材の扱い方を身につけます。協力しながら作業することでコミュニケーション力も向上します。",
      features: [
        "包丁やピーラーの安全な使用方法",
        "食材の洗い方・切り方の習得",
        "班での協力作業",
        "季節の食材を使った料理体験"
      ],
      duration: "月2回・各100分",
      color: "orange"
    },
    {
      icon: <BookOpen className="w-12 h-12 text-blue-500" />,
      title: "食に関する座学",
      description: "食材の栄養や旬、食と行事の関連について学びます。買い物体験を通じて実生活に役立つスキルも身につけます。",
      features: [
        "食材の栄養成分と効果",
        "季節の食材と価格の変化",
        "食事マナーと衛生管理",
        "買い物の実践とお金の計算"
      ],
      duration: "調理前10分＋月1回50分",
      color: "blue"
    },
    {
      icon: <Palette className="w-12 h-12 text-purple-500" />,
      title: "食に関する制作活動",
      description: "食をテーマにした工作や制作を通じて、食への関心と創造性を育みます。作品作りで達成感も味わえます。",
      features: [
        "調理レシピ集の制作",
        "紙粘土での弁当作り",
        "野菜・果物の工作",
        "食をテーマにした手芸品"
      ],
      duration: "月1回・50分",
      color: "purple"
    }
  ];

  const getColorClasses = (color) => {
    const colorMap = {
      orange: {
        bg: "bg-orange-50",
        border: "border-orange-200",
        text: "text-orange-800",
        button: "bg-orange-500 hover:bg-orange-600"
      },
      blue: {
        bg: "bg-blue-50",
        border: "border-blue-200",
        text: "text-blue-800",
        button: "bg-blue-500 hover:bg-blue-600"
      },
      purple: {
        bg: "bg-purple-50",
        border: "border-purple-200",
        text: "text-purple-800",
        button: "bg-purple-500 hover:bg-purple-600"
      }
    };
    return colorMap[color];
  };

  return (
    <section id="programs" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            3つの柱で構成される食育プログラム
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            調理活動、座学、制作活動の3つのアプローチで、
            子どもたちの食に対する理解と興味を総合的に育みます。
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {programs.map((program, index) => {
            const colors = getColorClasses(program.color);
            return (
              <div
                key={index}
                className={`${colors.bg} ${colors.border} border-2 rounded-2xl p-8 hover:shadow-lg transition-shadow duration-300`}
              >
                <div className="flex items-center justify-center w-20 h-20 bg-white rounded-full mb-6 mx-auto shadow-md">
                  {program.icon}
                </div>
                
                <h3 className="text-2xl font-bold text-gray-900 mb-4 text-center">
                  {program.title}
                </h3>
                
                <p className="text-gray-700 mb-6 leading-relaxed">
                  {program.description}
                </p>
                
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">主な内容：</h4>
                  <ul className="space-y-2">
                    {program.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="text-gray-700 text-sm">
                        • {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className={`${colors.bg} p-3 rounded-lg border ${colors.border}`}>
                  <p className={`text-sm font-semibold ${colors.text}`}>
                    実施頻度: {program.duration}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-0">
            <div className="p-8 lg:p-12">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                プログラムの特徴
              </h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-700">
                    <strong>個別対応：</strong>一人ひとりの特性に合わせたサポート
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-700">
                    <strong>視覚的支援：</strong>イラストや手順書で分かりやすく説明
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-700">
                    <strong>段階的アプローチ：</strong>スモールステップで確実に習得
                  </p>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-gray-700">
                    <strong>家族連携：</strong>保護者との情報共有と家庭での実践サポート
                  </p>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img
                src={cookingImage}
                alt="子どもたちがキッチンでお手伝いをしている様子"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProgramSection;

