import React from 'react';
import './App.css';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import ImportanceSection from './components/ImportanceSection';
import ProgramSection from './components/ProgramSection';
import SuccessStories from './components/SuccessStories';
import PracticalTips from './components/PracticalTips';
import ExpertAdvice from './components/ExpertAdvice';
import Resources from './components/Resources';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <HeroSection />
        <ImportanceSection />
        <ProgramSection />
        <SuccessStories />
        <PracticalTips />
        <ExpertAdvice />
        <Resources />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;

