import React from 'react';
import { Brain, Heart, Users, TrendingUp } from 'lucide-react';
import vegetablesImage from '../assets/fresh_vegetables.jpg';

const ImportanceSection = () => {
  const benefits = [
    {
      icon: <Brain className="w-8 h-8 text-blue-600" />,
      title: "脳の発達をサポート",
      description: "オメガ3脂肪酸、ビタミンD、鉄分などの栄養素が集中力向上と行動の安定化に寄与します。"
    },
    {
      icon: <Heart className="w-8 h-8 text-red-500" />,
      title: "心の健康を育む",
      description: "バランスの取れた食事は感情の安定と自己肯定感の向上につながります。"
    },
    {
      icon: <Users className="w-8 h-8 text-green-600" />,
      title: "社会性の発達",
      description: "食事を通じたコミュニケーションで協調性と社会的スキルを身につけます。"
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-orange-500" />,
      title: "継続的な成長",
      description: "段階的なアプローチで子どもたちの可能性を最大限に引き出します。"
    }
  ];

  return (
    <section id="importance" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            なぜ食育が重要なのか
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            発達障害を持つ子どもたちにとって、適切な栄養と食育は心身の健やかな成長に欠かせません。
            科学的根拠に基づいたアプローチで、一人ひとりの特性に合わせたサポートを提供します。
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <img
              src={vegetablesImage}
              alt="新鮮でカラフルな野菜"
              className="w-full h-auto rounded-2xl shadow-lg"
            />
          </div>
          
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                栄養が与える影響
              </h3>
              <p className="text-gray-600 leading-relaxed mb-6">
                発達障害の子どもたちは感覚過敏や固定された嗜好により偏食になりがちです。
                栄養の偏りは心や体のさまざまな症状として現れることがあります。
                適切な栄養管理により、これらの症状の改善が期待できます。
              </p>
            </div>
            
            <div className="bg-green-50 p-6 rounded-xl">
              <h4 className="text-lg font-semibold text-green-800 mb-3">
                重要な栄養素
              </h4>
              <ul className="space-y-2 text-green-700">
                <li>• オメガ3脂肪酸：脳機能の向上</li>
                <li>• ビタミンD：神経系の発達</li>
                <li>• 鉄分：集中力の維持</li>
                <li>• ビタミンB群：エネルギー代謝</li>
                <li>• 亜鉛：免疫機能の強化</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-100"
            >
              <div className="flex items-center justify-center w-16 h-16 bg-gray-50 rounded-full mb-4 mx-auto">
                {benefit.icon}
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3 text-center">
                {benefit.title}
              </h3>
              <p className="text-gray-600 text-center leading-relaxed">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ImportanceSection;

