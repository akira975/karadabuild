import React from 'react';
import { Download, ExternalLink, BookOpen, FileText, Video, Users } from 'lucide-react';

const Resources = () => {
  const downloadResources = [
    {
      icon: <FileText className="w-8 h-8 text-blue-600" />,
      title: "食育活動ガイドブック",
      description: "家庭でできる食育活動の具体的な方法をまとめたガイドブック",
      format: "PDF",
      size: "2.5MB",
      color: "blue"
    },
    {
      icon: <BookOpen className="w-8 h-8 text-green-600" />,
      title: "栄養バランスチェックシート",
      description: "日々の食事の栄養バランスを簡単にチェックできるシート",
      format: "PDF",
      size: "1.2MB",
      color: "green"
    },
    {
      icon: <Users className="w-8 h-8 text-purple-600" />,
      title: "発達障害児の食事サポートマニュアル",
      description: "発達障害の特性に応じた食事サポートの方法を詳しく解説",
      format: "PDF",
      size: "3.1MB",
      color: "purple"
    }
  ];

  const externalLinks = [
    {
      title: "厚生労働省 食育推進基本計画",
      description: "国の食育推進に関する基本的な方針と取り組み",
      url: "https://www.mhlw.go.jp/",
      category: "政府資料"
    },
    {
      title: "日本発達障害ネットワーク",
      description: "発達障害に関する最新情報と支援リソース",
      url: "https://jddnet.jp/",
      category: "支援団体"
    },
    {
      title: "日本栄養士会",
      description: "栄養・食事に関する専門的な情報とガイドライン",
      url: "https://www.dietitian.or.jp/",
      category: "専門団体"
    },
    {
      title: "全国児童発達支援協議会",
      description: "児童発達支援に関する情報と事業所検索",
      url: "https://www.jidou-hattatsu.jp/",
      category: "支援団体"
    }
  ];

  const supportInfo = [
    {
      title: "地域の発達支援センター",
      description: "お住まいの地域の発達支援センターで相談・支援を受けることができます",
      contact: "市区町村の福祉課にお問い合わせください"
    },
    {
      title: "管理栄養士による栄養相談",
      description: "医療機関や保健センターで栄養に関する専門的な相談が可能です",
      contact: "かかりつけ医または保健センターにご相談ください"
    },
    {
      title: "親の会・支援グループ",
      description: "同じ悩みを持つ保護者同士の情報交換と相互支援",
      contact: "地域の発達支援センターで情報を提供しています"
    }
  ];

  const getColorClasses = (color) => {
    const colorMap = {
      blue: "bg-blue-50 border-blue-200 text-blue-800",
      green: "bg-green-50 border-green-200 text-green-800",
      purple: "bg-purple-50 border-purple-200 text-purple-800"
    };
    return colorMap[color] || colorMap.blue;
  };

  return (
    <section id="resources" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            リソース・サポート情報
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            食育プログラムをより効果的に進めるための資料や、
            専門的なサポートを受けられる機関をご紹介します。
          </p>
        </div>

        {/* Download Resources */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            ダウンロード資料
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {downloadResources.map((resource, index) => (
              <div
                key={index}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <div className="flex items-center justify-center w-16 h-16 bg-gray-50 rounded-full mb-4 mx-auto">
                  {resource.icon}
                </div>
                
                <h4 className="text-lg font-semibold text-gray-900 mb-3 text-center">
                  {resource.title}
                </h4>
                
                <p className="text-gray-600 text-center mb-4 leading-relaxed">
                  {resource.description}
                </p>
                
                <div className="flex justify-between items-center mb-4">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getColorClasses(resource.color)}`}>
                    {resource.format}
                  </span>
                  <span className="text-sm text-gray-500">
                    {resource.size}
                  </span>
                </div>
                
                <button className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors duration-200 flex items-center justify-center space-x-2">
                  <Download className="w-5 h-5" />
                  <span>ダウンロード</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* External Links */}
        <div className="mb-16">
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            関連リンク
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {externalLinks.map((link, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow duration-300"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h4 className="text-lg font-semibold text-gray-900 mb-2">
                      {link.title}
                    </h4>
                    <p className="text-gray-600 text-sm mb-3">
                      {link.description}
                    </p>
                    <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                      {link.category}
                    </span>
                  </div>
                  <ExternalLink className="w-5 h-5 text-gray-400 ml-4 flex-shrink-0" />
                </div>
                <a
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-800 text-sm font-medium"
                >
                  サイトを見る →
                </a>
              </div>
            ))}
          </div>
        </div>

        {/* Support Information */}
        <div>
          <h3 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            サポート機関・相談窓口
          </h3>
          <div className="space-y-6">
            {supportInfo.map((info, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-md border-l-4 border-green-500"
              >
                <h4 className="text-lg font-semibold text-gray-900 mb-3">
                  {info.title}
                </h4>
                <p className="text-gray-700 mb-3 leading-relaxed">
                  {info.description}
                </p>
                <div className="bg-green-50 p-3 rounded-lg">
                  <p className="text-green-800 text-sm font-medium">
                    📞 {info.contact}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-600 to-green-600 rounded-2xl p-8 text-center text-white">
          <h3 className="text-2xl font-bold mb-4">
            さらに詳しい情報が必要ですか？
          </h3>
          <p className="text-lg mb-6 opacity-90">
            個別のご相談や追加の資料提供も承っております
          </p>
          <a
            href="#contact"
            className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200 inline-block"
          >
            お問い合わせする
          </a>
        </div>
      </div>
    </section>
  );
};

export default Resources;

