import React from 'react';
import { User, Award, MessageCircle } from 'lucide-react';

const ExpertAdvice = () => {
  const experts = [
    {
      name: "田中 美香",
      title: "管理栄養士・食育指導士",
      credentials: "栄養学修士、発達支援栄養専門士",
      image: "👩‍⚕️",
      advice: "発達障害のお子さまの食育では、栄養バランスだけでなく、食べる楽しさを伝えることが重要です。一人ひとりの特性を理解し、その子に合ったアプローチを見つけることで、必ず変化が現れます。保護者の皆さまも完璧を求めず、小さな成長を一緒に喜んでください。",
      specialties: ["偏食改善", "栄養指導", "家族サポート"]
    },
    {
      name: "佐藤 健一",
      title: "発達支援専門家・作業療法士",
      credentials: "作業療法士、感覚統合療法認定士",
      image: "👨‍⚕️",
      advice: "感覚過敏のあるお子さまには、段階的なアプローチが効果的です。まずは見る、触る、匂いを嗅ぐといった段階を踏み、無理をせずに進めることが大切です。調理活動を通じて手指の巧緻性や協調性も向上し、総合的な発達支援につながります。",
      specialties: ["感覚統合", "作業療法", "発達支援"]
    },
    {
      name: "山田 恵子",
      title: "臨床心理士・家族療法士",
      credentials: "臨床心理士、公認心理師",
      image: "👩‍🎓",
      advice: "食事は家族のコミュニケーションの場でもあります。お子さまの食事の困りごとは、家族全体で取り組むことが重要です。保護者の皆さまの不安や悩みにも寄り添いながら、家族みんなが笑顔で食事を楽しめる環境づくりをサポートします。",
      specialties: ["家族療法", "心理カウンセリング", "親子関係"]
    }
  ];

  const faqs = [
    {
      question: "偏食がひどく、栄養が心配です。どうすればよいでしょうか？",
      answer: "まずは食べられるものから栄養価を高める工夫をしましょう。好きな食材に少しずつ新しい食材を混ぜたり、調理法を変えたりすることから始めます。栄養補助食品の活用も検討できますが、専門家にご相談ください。"
    },
    {
      question: "食事中に立ち歩いてしまいます。どう対応すればよいですか？",
      answer: "集中できる環境づくりが重要です。テレビを消し、おもちゃを片付けて、食事に集中できる空間を作りましょう。また、食事時間を短めに設定し、座っていられた時間を褒めることから始めてください。"
    },
    {
      question: "家族で同じ食事を食べられません。どうしたらよいでしょうか？",
      answer: "無理に同じものを食べさせる必要はありません。まずは同じテーブルで食事をすることから始め、徐々に家族の食事に興味を持てるよう環境を整えましょう。時間をかけて少しずつ進めることが大切です。"
    }
  ];

  return (
    <section id="expert" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
            専門家からのアドバイス
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            食育と発達支援の専門家が、科学的根拠に基づいた
            実践的なアドバイスをお届けします。
          </p>
        </div>

        {/* Expert Profiles */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {experts.map((expert, index) => (
            <div
              key={index}
              className="bg-gradient-to-br from-blue-50 to-green-50 rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow duration-300"
            >
              <div className="text-center mb-6">
                <div className="text-6xl mb-4">{expert.image}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {expert.name}
                </h3>
                <p className="text-blue-600 font-semibold mb-2">
                  {expert.title}
                </p>
                <p className="text-sm text-gray-600">
                  {expert.credentials}
                </p>
              </div>
              
              <blockquote className="text-gray-700 leading-relaxed mb-6 italic">
                "{expert.advice}"
              </blockquote>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">専門分野：</h4>
                <div className="flex flex-wrap gap-2">
                  {expert.specialties.map((specialty, specialtyIndex) => (
                    <span
                      key={specialtyIndex}
                      className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                    >
                      {specialty}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="bg-gray-50 rounded-2xl p-8">
          <div className="text-center mb-12">
            <MessageCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              よくあるご質問
            </h3>
            <p className="text-gray-600">
              保護者の皆さまからよく寄せられるご質問にお答えします
            </p>
          </div>
          
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-6 shadow-md"
              >
                <h4 className="text-lg font-semibold text-gray-900 mb-3 flex items-start">
                  <span className="bg-green-100 text-green-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5 flex-shrink-0">
                    Q
                  </span>
                  {faq.question}
                </h4>
                <div className="ml-9">
                  <p className="text-gray-700 leading-relaxed">
                    <span className="bg-blue-100 text-blue-800 rounded-full w-6 h-6 inline-flex items-center justify-center text-sm font-bold mr-3">
                      A
                    </span>
                    {faq.answer}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 text-center">
          <div className="bg-gradient-to-r from-green-600 to-blue-600 rounded-2xl p-8 text-white">
            <Award className="w-12 h-12 mx-auto mb-4" />
            <h3 className="text-2xl font-bold mb-4">
              個別相談も承っております
            </h3>
            <p className="text-lg mb-6 opacity-90">
              お子さまの状況に合わせた個別のアドバイスをご希望の方は、
              専門家による個別相談をご利用ください
            </p>
            <a
              href="#contact"
              className="bg-white text-green-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-200 inline-block"
            >
              個別相談を申し込む
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ExpertAdvice;

