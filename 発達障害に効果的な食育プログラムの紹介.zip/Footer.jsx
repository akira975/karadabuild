import React from 'react';
import { Heart, Mail, Phone, MapPin } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    about: [
      { label: "食育プログラムについて", href: "#programs" },
      { label: "専門家紹介", href: "#expert" },
      { label: "成功事例", href: "#success" },
      { label: "よくあるご質問", href: "#expert" }
    ],
    support: [
      { label: "家庭での実践方法", href: "#tips" },
      { label: "ダウンロード資料", href: "#resources" },
      { label: "関連リンク", href: "#resources" },
      { label: "サポート機関", href: "#resources" }
    ],
    contact: [
      { label: "お問い合わせフォーム", href: "#contact" },
      { label: "個別相談申し込み", href: "#contact" },
      { label: "プログラム参加申し込み", href: "#contact" }
    ]
  };

  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <Heart className="w-8 h-8 text-green-400" />
              <h3 className="text-xl font-bold">食育プログラム</h3>
            </div>
            <p className="text-gray-300 leading-relaxed mb-6">
              発達障害を持つ子どもたちとその家族が、
              食を通じて笑顔と健康を育むためのサポートを提供しています。
            </p>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-green-400" />
                <span className="text-gray-300">03-1234-5678</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-green-400" />
                <span className="text-gray-300">info@food-education.jp</span>
              </div>
              <div className="flex items-center space-x-3">
                <MapPin className="w-5 h-5 text-green-400" />
                <span className="text-gray-300">東京都渋谷区○○ 1-2-3</span>
              </div>
            </div>
          </div>

          {/* About Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">プログラムについて</h4>
            <ul className="space-y-3">
              {footerLinks.about.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-green-400 transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Support Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">サポート・リソース</h4>
            <ul className="space-y-3">
              {footerLinks.support.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-green-400 transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">お問い合わせ</h4>
            <ul className="space-y-3">
              {footerLinks.contact.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    className="text-gray-300 hover:text-green-400 transition-colors duration-200"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
            
            <div className="mt-8">
              <h5 className="text-sm font-semibold text-gray-400 mb-3">受付時間</h5>
              <p className="text-gray-300 text-sm">
                平日 9:00-18:00<br />
                土日祝日はメールでお問い合わせください
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © {currentYear} 食育プログラム. All rights reserved.
            </div>
            
            <div className="flex space-x-6 text-sm">
              <a
                href="#"
                className="text-gray-400 hover:text-green-400 transition-colors duration-200"
              >
                プライバシーポリシー
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-green-400 transition-colors duration-200"
              >
                利用規約
              </a>
              <a
                href="#"
                className="text-gray-400 hover:text-green-400 transition-colors duration-200"
              >
                サイトマップ
              </a>
            </div>
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-gray-400 text-sm leading-relaxed">
              このサイトは発達障害を持つ子どもたちとその家族を支援することを目的としています。<br />
              専門的な医療アドバイスの代替ではありませんので、医療に関するご相談は専門医にお尋ねください。
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

